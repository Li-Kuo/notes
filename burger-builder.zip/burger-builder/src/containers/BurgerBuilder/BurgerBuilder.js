import React, {useState} from 'react';
import Aux from '../../hoc/Aux';
import Ingredient from '../../components/Burger/Ingredient/Ingredient';
import Burger from '../../components/Burger/Burger';
import BuildControls from '../../components/Burger/BuildControls/BuildControls';
import Modal from '../../components/UI/Modal/Modal';
import OrderSummary from '../../components/Burger/OrderSummary/OrderSummary';


const INGREDIENT_PRICE = {
    salad: 0.3,
    bacon: 0.7,
    cheese: 1,
    meat: 1.5
}

const INGREDIENT_CALORIE = {
    salad: 14,
    bacon: 80,
    cheese: 60,
    meat: 280
}

function BurgerBuilder(props){

    const [ingredientState, setIngredientState] = useState(
        {
            salad: 0, 
            bacon: 0, 
            cheese: 0, 
            meat: 0
        }
    );


    const [totalPriceState, setTotalPriceState] = useState(
        {price: 4}
    );

    const [totalCaloriesState, setTotalCaloriesState] = useState(
        {calories: 250}
    );

    
    const [purchaseState, setPurchaseState] = useState(
        {canPurchase: false}
    );
    
    
    const [orderState, setOrderState] = useState(
        {order: false}
    );

    

    const orderHandler = () => {
        setOrderState({order: true});
    }



    // ingredients = {salad: 0, bacon: 2, cheese: 0, meat: 0}
    const purchaseHandler = (ingredientState)=>{
                  // ['salad', 'bacon', 'cheese', 'meat']
        let sum = Object.keys(ingredientState).map(
            name => ingredientState[name]
            // [0, 2, 0, 0]
        ).reduce(
            (a,b) => a+b
        );

        if (sum == 0){
            setPurchaseState({canPurchase: false});
        }else {
            setPurchaseState({canPurchase: true});
        }
    }

    const closeModalHandler = () => {
        setOrderState({order: false});
    }

    const continuePurchaseHandler = () => {
        alert('You Continue!');
    }

   
    
    const addHandler = (type)=>{
        // ingredients 指向 複製的ingredientsState
        let ingredients = {...ingredientState};
        ingredients[type] = ingredients[type] + 1;

        setIngredientState(ingredients);


        // totalPrice 指向 複製的totalPriceState
        let totalPrice = {...totalPriceState}

        totalPrice.price = totalPrice.price + INGREDIENT_PRICE[type];

        setTotalPriceState(totalPrice);

        // totalCalories 指向 複製的totalCaloriesState
        let totalCalories = {...totalCaloriesState};
        totalCalories.calories = totalCalories.calories + INGREDIENT_CALORIE[type];
        setTotalCaloriesState(totalCalories);

        // 把剛剛操作完的 ingredients 傳入 purchaseHandler
        purchaseHandler(ingredients);

    }

    const deleteHandler = (type) =>{
        let ingredients = {...ingredientState};

        ingredients[type] = ingredients[type] - 1;

        setIngredientState(ingredients);

        let totalPrice = {...totalPriceState};
        totalPrice.price = totalPrice.price - INGREDIENT_PRICE[type];

        setTotalPriceState(totalPrice);

        let totalCalories = {...totalCaloriesState};
        totalCalories.calories = totalCalories.calories - INGREDIENT_CALORIE[type];
        setTotalCaloriesState(totalCalories);

        // 把剛剛操作完的 ingredients 傳入 purchaseHandler
        purchaseHandler(ingredients);
    }

    
    const ingredients = {...ingredientState};

    // {salad: 0, bacon: 2, cheese: 0, meat: 0} =>
    //  {salad: true, bacon: false, cheese: true, meat: true}
    for (let key in ingredients){
        ingredients[key] = ingredients[key] == 0;
    }




    const clearHandler = ()=> {
        let ingredients = {
            salad: 0, 
            bacon: 0, 
            cheese: 0, 
            meat: 0
        };

        setIngredientState(ingredients);

        setPurchaseState({canPurchase: false});


    }



    


    return (
        <Aux>
            <Burger ingredients={ingredientState} />
            <Modal show={orderState.order} click={closeModalHandler}>
                <OrderSummary 
                ingredientState={ingredientState}
                price={totalPriceState.price}
                closeModal={closeModalHandler}
                continuePurchase={continuePurchaseHandler}
                />
            </Modal>
            <BuildControls 
            add={addHandler} 
            delete={deleteHandler}
            clear={clearHandler} 
            disable={ingredients} 
            price={totalPriceState.price} 
            calories={totalCaloriesState.calories}
            purchase={purchaseState.canPurchase}
            order={orderHandler}
            />
        </Aux>
    );
}



export default BurgerBuilder;