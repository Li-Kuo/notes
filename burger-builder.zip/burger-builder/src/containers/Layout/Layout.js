import React, { useState } from "react";
import Aux from "../../hoc/Aux";
import styles from "../Layout/Layout.module.css";
import Toolbar from "../../components/Navigation/Toolbar/Toolbar";
import SideDrawer from "../../components/Navigation/SideDrawer/SideDrawer";

function Layout(props) {
  const [sideDrawerState, setSideDrawerState] = useState(true);

  const toggleSideDrawerHandler = () => {
    setSideDrawerState(!sideDrawerState);
  };
  return (
    <Aux>
      <Toolbar click={toggleSideDrawerHandler} />
      <SideDrawer show={sideDrawerState} click={toggleSideDrawerHandler} />
      <main className={styles.content}>{props.children}</main>
    </Aux>
  );
}

export default Layout;
