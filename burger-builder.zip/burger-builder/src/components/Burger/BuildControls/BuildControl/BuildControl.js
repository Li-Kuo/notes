import React from 'react';
import styles from '../BuildControl/BuildControl.module.css';

function BuildControl(props) {
    return (
        <div className={styles.BuildControl}>
            <div style={{width: '60px'}}>{props.label}</div>
            <button className={styles.More} onClick={props.add}>More</button>
            <button className={styles.Less} onClick={props.delete} disabled={props.disable}>
                Less
            </button>
        </div>
    );
    
}



export default BuildControl;