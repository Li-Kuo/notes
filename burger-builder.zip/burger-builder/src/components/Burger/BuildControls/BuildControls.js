import React from 'react';
import styles from '../BuildControls/BuildControls.module.css';
import BuildControl from './BuildControl/BuildControl';

function BuildControls(props) {
    const controls = [
        {label: 'Salad', type: 'salad'}, 
        {label: 'Bacon', type: 'bacon'}, 
        {label: 'Cheese', type: 'cheese'}, 
        {label: 'Meat', type: 'meat'} 
    ];

    let controlList = controls.map(        
        c => <BuildControl 
        key={c.label} 
        label={c.label}
        add={()=>props.add(c.type)} 
        delete={()=>props.delete(c.type)}
        //把 true or false 傳進去
        disable ={props.disable[c.type]}
        />
    );





    return (
        <div className={styles.BuildControls}>
            <p>Price: <strong>{props.price.toFixed(2)}</strong> &nbsp;&nbsp;&nbsp;Calories: <strong>{props.calories}</strong></p>
            {controlList}
            <br />
            <button className={styles.OrderButton} onClick={props.clear}>Clear All</button>
            <br />
            <button onClick={props.order} disabled={!props.purchase} className={styles.OrderButton}>
                Order Now!
            </button>
        </div>
    );
}


export default BuildControls;