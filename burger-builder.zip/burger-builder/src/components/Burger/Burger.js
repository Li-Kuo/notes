import React, { useReducer } from 'react';
import styles from '../Burger/Burger.module.css';
import Ingredient from './Ingredient/Ingredient';



function Burger(props) {

    // keys() 把 object 轉換成 array   
    // {salad: 1, bacon: 1, cheese: 2, meat: 2} => ['salad', 'bacon', 'cheese', 'meat']
    const iArray = Object.keys(props.ingredients);
    
    let iList = iArray.map(
        (ingredienName) => [...Array(props.ingredients[ingredienName])].map(
            (blank, index) => <Ingredient key={ingredienName + index} type={ingredienName} />
        )
    ).reduce(
        (a, b) => a.concat(b)
    );
    

    if (iList.length === 0){
        iList = <p>Add Ingredients!</p>;
    }

    
    
    


    return (
        <div className={styles.burger}>
            <Ingredient type="bread-top" />
            {iList}
            <Ingredient type="bread-bottom" />
        </div>
    );
}




export default Burger;