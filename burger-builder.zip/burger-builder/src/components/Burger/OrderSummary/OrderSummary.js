import React from "react";
import Aux from "../../../hoc/Aux";
import Button from "../../UI/Button/Button";

function OrderSummary(props) {
  let summary = Object.keys(props.ingredientState).map(igkey => (
    <li key={igkey}>
      {igkey}: {props.ingredientState[igkey]}
    </li>
  ));

  return (
    <Aux>
      <h3>Your Order</h3>
      <p>BIGMAC with the following ingredients:</p>
      <ul>{summary}</ul>
      <p>Price:&nbsp; &nbsp; &nbsp; {props.price.toFixed(2)}</p>
      <br />
      <p>continue to check out?</p>

      <Button buttonType="Danger" click={props.closeModal}>
        CANCEL
      </Button>

      <Button buttonType="Success" click={props.continuePurchase}>
        CONTINUE
      </Button>
    </Aux>
  );
}

export default OrderSummary;
