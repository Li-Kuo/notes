import React from 'react';
import burgerLogo from '../../assets/images/burger-logo.png';
import styles from '../Logo/Logo.module.css';

function Logo(props){
    return (
        <div className={styles.Logo} style={{height: props.height, marginBottom: props.mb}}>
            <img src={burgerLogo} alt="MyBurger" />
        </div>
    );
}


export default Logo;