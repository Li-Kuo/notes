import React from 'react';
import styles from '../Button/Button.module.css';

function Button(props){
    return (
        <button
        className={[styles.Button, styles[props.buttonType]].join(' ')}
        onClick={props.click}
        >
            {props.children}
        </button>
    );
}


export default Button;