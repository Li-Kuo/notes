import React from 'react';
import style from '../Backdrop/Backdrop.module.css';

function Backdrop(props){
    return (
        props.show ? <div className={style.Backdrop} onClick={props.click}></div> : null
    );
}

export default Backdrop;