import React from 'react';
import styles from '../Toolbar/Toolbar.module.css';
import Logo from '../../Logo/Logo';
import NavigationItems from '../NavigationItems/NavigationItems';
import DrawerToggle from '../SideDrawer/DrawerToggle/DrawerToggle';

function Toolbar(props){
    return (
        <header  className={styles.Toolbar}>
            <DrawerToggle click={props.click} />
            <Logo />
            <nav className={styles.Mobile}>
                <NavigationItems />
            </nav>
        </header>
    );
    
}



export default Toolbar;