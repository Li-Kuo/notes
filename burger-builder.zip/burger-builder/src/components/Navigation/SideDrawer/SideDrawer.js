import React from 'react';
import NavigationItems from '../NavigationItems/NavigationItems';
import Logo from '../../Logo/Logo';
import '../SideDrawer/SideDrawer.css';
import Backdrop from '../../UI/Backdrop/Backdrop';
import Aux from '../../../hoc/Aux';

function SideDrawer(props) {
    
    let classes;

    if (props.show){
        classes = "SideDrawer Open";
    }else {
        classes = "SideDrawer Close";
    }


    return (
        <Aux>
            <Backdrop show={props.show} click={props.click} />
            <div className={classes}>
                <Logo height='11%' mb='32px' />
                <nav>
                    <NavigationItems />
                </nav>
            </div>
        </Aux>
    );
}

export default SideDrawer;